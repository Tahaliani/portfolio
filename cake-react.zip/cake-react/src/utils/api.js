import axios from 'axios';
import { toast } from 'react-hot-toast';
import Config from "../core/config/Config";

export default class Api {

    static async post(endpoint, data, headers = {}, params = {}) {
        const url = `https://${Config.apiDomain}/apis/v1/core${endpoint}`;
        console.log(url);
        const body = JSON.stringify(data);
        console.log(body);
        try {
            const response = await axios.post(url, body, { headers, params });
            console.log(response.data);
            return response.data;
        } catch (error) {
            const responseBody = error.response.data;
            toast.error(responseBody.message);
            return null;
        }
    }

    static async get(endpoint, headers = {}, params = {}) {
        const url = `https://${Config.apiDomain}/apis/v1/core${endpoint}`;
        console.log(url);
        try {
            const response = await axios.get(url, { headers, params });
            console.log(response.data);
            return response.data;
        } catch (error) {
            const responseBody = error.response.data;
            // toast.error(responseBody.message);
            return null;
        }
    }

    static async delete(endpoint, headers = {}, params = {}) {
        const url = `https://${Config.apiDomain}/apis/v1/core${endpoint}`;
        console.log(url);
        try {
            const response = await axios.delete(url, { headers, params });
            console.log(response.data);
            return response.data;
        } catch (error) {
            const responseBody = error.response.data;
            toast.error(responseBody.message);
            return null;
        }
    }

    static async patch(endpoint, data, headers = {}) {
        const url = `https://${Config.apiDomain}/apis/v1/core${endpoint}`;
        console.log(url);
        const body = JSON.stringify(data);
        try {
            const response = await axios.patch(url, body, { headers });
            console.log(response.data);
            return response.data;
        } catch (error) {
            const responseBody = error.response.data;
            toast.error(responseBody.message);
            return null;
        }
    }

    static async upload(endpoint, headers = {}, files = []) {
        const url = `https://${Config.apiDomain}/apis/v1/core${endpoint}`;
        console.log(url);
        const formData = new FormData();
        for (let x = 0; x < files.length; x++) {
            formData.append('files', files[x]);
        }
        try {
            const response = await axios.post(url, formData, { headers });
            console.log(response.data);
            return response.data;
        } catch (error) {
            const responseBody = error.response.data;
            toast.error(responseBody.message);
            return null;
        }
    }
}
