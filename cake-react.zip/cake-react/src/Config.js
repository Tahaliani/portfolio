const Config = {
    apiBaseUrl: "http://localhost:4444/apis/v1/core/user",
    apiCoreBaseUrl: "http://localhost:4444/apis/v1/core"
};

export default Config;
