import { Link, useNavigate } from "react-router-dom";

const Cart = () => {
    const navigate = useNavigate();

    return (
        <>
            <div className="cart-screen">
  <div className="cart-screen-content">
    <span className="cart-heading">Cart</span>
    <div className="cart-cake-desc">
      <div className="row">
        <div className="col">
          <img src="assets/images/flavour-1.png" height="80px" alt="" />
        </div>
        <div className="col-md-auto">
          <span className="cake-title">
            Double Barrel Cake{" "}
            <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAACXBIWXMAAAsTAAALEwEAmpwYAAAA8ElEQVR4nO2Uvw4BQRDGt5QoZi4kwutQ4Gm8hIaa1gvcLCqPQSNOJaG5uN2SErlzG46z92dPd18yze7s95v9NlnGCtaZ6k3BYSMIR+wfEgRTyfHul+A4LnZygsFhxiqCwyoAEK4jTdK2+pLDSU2gL7gKGzrKXBI64fowhEz89SjA2Byf0RAMYq+pGtLG4i6rDUmwjcAJ996i1jIGuFnN3wFJsbh5zPUAiGbOYfdh7qgHVX25I5Iac28ObX8YQwDGmgd7BBft+UwA+s5cEN6MATqVgESVERURUdrvGn+WIDhqAFbPbzAxl2R1k+9air30AJoq4Ov5xBvSAAAAAElFTkSuQmCC" />
          </span>
          <br />
          <span className="cake-flavour">Pistachio</span>
          <br />
          <span className="cake-price">SAR 580.00</span>
        </div>
      </div>
      <div className="add-more">
        <div className="col-md-auto">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            x="0px"
            y="0px"
            width={24}
            height={24}
            viewBox="0,0,256,256"
            style={{ fill: "#000000" }}
          >
            <g
              fill="#edae10"
              fillRule="nonzero"
              stroke="none"
              strokeWidth={1}
              strokeLinecap="butt"
              strokeLinejoin="miter"
              strokeMiterlimit={10}
              strokeDasharray=""
              strokeDashoffset={0}
              fontFamily="none"
              fontWeight="none"
              fontSize="none"
              textAnchor="none"
              style={{ mixBlendMode: "normal" }}
            >
              <g transform="scale(10.66667,10.66667)">
                <path d="M10,2l-1,1h-5v2h1v15c0,0.52222 0.19133,1.05461 0.56836,1.43164c0.37703,0.37703 0.90942,0.56836 1.43164,0.56836h10c0.52222,0 1.05461,-0.19133 1.43164,-0.56836c0.37703,-0.37703 0.56836,-0.90942 0.56836,-1.43164v-15h1v-2h-5l-1,-1zM7,5h10v15h-10zM9,7v11h2v-11zM13,7v11h2v-11z"></path>
              </g>
            </g>
          </svg>
        </div>
        <div className="col-md-auto">
          <span className="cake-price" style={{ margin: "0pc 10px" }}>
            1
          </span>
        </div>
        <div className="col-md-auto">
          <div style={{ height: 30, width: 30 }}>
            <img
              height="30px"
              width="30px"
              src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAACXBIWXMAAAsTAAALEwEAmpwYAAABP0lEQVR4nN1US07DQAwdFbXL2LkOCmcAAS3H6ZZSLtA1CCSEneM0pZQLdJxFYR/kkApBMp38NmDJm9HMe/az5xnzryN7MiN5Dq4swYMQJkLw8ZWY5GccTPROK3Abw4Vl3Ahjdigt4atlOG9S9ZFlvPUBy28ixnk2NQN/5S3A5bubmVeWtuBS5DaGM5c0I9WzK4ElfKscvG6LFyAOj1MOIz8RjCu0h0ffQ7MvxjtwuC93wPjSF4EQJmUCgp1LFuMIp1wEu9oEKYeRkyDGkwYEuOpNIoZleci5t/Q0ZIK7iiEHE9/DlMPIKctPgssSQbYwQyFcN/1YUlpR3DgdVl2xK8GW8dS1FAUJzjtUf30QPJdqagaW8KYxOOGsll3vQ12x1kwI115ZnN0szFCNS71Fd1sY3otc6plui95pBf5n4hPfcjh+EiklbgAAAABJRU5ErkJggg=="
            />
          </div>
        </div>
      </div>
    </div>
    <div className="cart-sec-heading">Card Message</div>
    <div className="card-message-box">
      <h1>There's no card message included with your order..</h1>
      <h2>Add card message</h2>
    </div>
    <div className="cart-sec-heading">Recipient in Kota</div>
    <div className="recipient-details">
      <div className="recipient-row">
        <div style={{ height: 20, width: 20 }}>
          <img
            height="20px"
            width="20px"
            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAACXBIWXMAAAsTAAALEwEAmpwYAAABP0lEQVR4nN1US07DQAwdFbXL2LkOCmcAAS3H6ZZSLtA1CCSEneM0pZQLdJxFYR/kkApBMp38NmDJm9HMe/az5xnzryN7MiN5Dq4swYMQJkLw8ZWY5GccTPROK3Abw4Vl3Ahjdigt4atlOG9S9ZFlvPUBy28ixnk2NQN/5S3A5bubmVeWtuBS5DaGM5c0I9WzK4ElfKscvG6LFyAOj1MOIz8RjCu0h0ffQ7MvxjtwuC93wPjSF4EQJmUCgp1LFuMIp1wEu9oEKYeRkyDGkwYEuOpNIoZleci5t/Q0ZIK7iiEHE9/DlMPIKctPgssSQbYwQyFcN/1YUlpR3DgdVl2xK8GW8dS1FAUJzjtUf30QPJdqagaW8KYxOOGsll3vQ12x1kwI115ZnN0szFCNS71Fd1sY3otc6plui95pBf5n4hPfcjh+EiklbgAAAABJRU5ErkJggg=="
          />
        </div>
        <h3>Add Recipient Details</h3>
      </div>
    </div>
    <br />
    <div className="identity-box">
      <h4>Keep my identity secret</h4>
      <input type="checkbox" defaultChecked="checked" />
    </div>
    <br />
    <div className="note-box">
      <div style={{ width: 20, height: 20 }}>
        <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAq0lEQVR4nO2UMQ6DMAxFfQKccKrC2sN07XlQk249DCNZ86vegKooQyWosFUsMfClP+a/yN8J0SGpcPMtIidEN8rMCdE3coAq3E3OgQcFQBeO4gMwSke0Wv6/HWCt/C0BWCp/l4BcRvHsPG8OyIEHBH/6nM13PssBga/ix0NEr66qEV0vAyjC86Ouys1n4cuAH+Gw/0I4GQN8MxVqBdAIgS+mgG8IWQrKVd+33iENiIzx7nCzAAAAAElFTkSuQmCC" />
      </div>
      <input type="text" placeholder="Leave a note" />
    </div>
  </div>
</div>

        </>

    );
}

export default Cart;
