import { Link, useNavigate } from "react-router-dom";
import React, { useState } from 'react';
import { useEffect } from 'react';

const Home = () => {
    const navigate = useNavigate();
    const [activeTab, setActiveTab] = useState('shape');

    const openCustomCakeTab = (cityName) => {
        setActiveTab(cityName);
    };

    const [activeShape, setActiveShape] = useState('shape1');

    const openShapes = (shape) => {
        setActiveShape(shape);
    };

    const [activeFlavour, setActiveFlavour] = useState('flavour1');

    const openFlavours = (evt, flavourName) => {
        setActiveFlavour(flavourName);
    };


    const [activeColor, setActiveColor] = useState('color1');
    const [customColor, setCustomColor] = useState('#FCBEBF');

    const handleColorChange = (event) => {
        setCustomColor(event.target.value);
    };

    useEffect(() => {
        document.getElementById('favcolor').parentElement.style.backgroundColor = customColor;
    }, [customColor]);

    const openColors = (event, colorName) => {
        setActiveColor(colorName);
        document.querySelectorAll('.tabcolorlinks').forEach(button => button.classList.remove('active'));
        event.currentTarget.classList.add('active');
    };

    const [activeTopping, setActiveTopping] = useState('topping1');

    const opentoppings = (event, toppingName) => {
        setActiveTopping(toppingName);
    };

    return (
        <>
            <div className="customize-tab">
                <div className="tab">
                    <button
                        className={`customizecaketablinks ${activeTab === 'shape' ? 'active' : ''}`}
                        onClick={() => openCustomCakeTab('shape')}
                    >
                        <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAACXBIWXMAAAsTAAALEwEAmpwYAAAB3klEQVR4nO2WO0tkQRCFKxCNFDHwGZoubLCJkRoJgqD4I1QQhfWFbGymBoYGZoaKgaE4gYiPQDDS/QdGIj5gxwd+0uwZaOXOBZ0r01f7g2ag6nRPnem6dccsEonkBqAO+AX0AJ2WN4AuYBO45zX7lgeAGmAFeFbhT8CZMwBcAHuWB4B1z8Ai0GKB9/0EcATcAdfAAbAmE/+AXgsZoAM4JZ3fFjL8v4mSiXNgEKjXGgL+KncC1FqoAJOeicaEfKNnZtxCBThWkYMpmmFpDi1UgFsVWZ+iaZDmxkIFuFGRbSmadmmuP7OQAWBXI9OtHfcGTtH3AgVpL4FHFTkK/AC2vLO2FBuT5lF77nRGT1YmFsqMSvcGHknQ/0kZr1dAMSFeVK4c81ncROmLZlxraM0q9gD89PR93l+MJaAZaAKmpUWf04q/zd17uRZg2fvR+isx4q7WMZOQm1Nu1YttK7aRoHcFOqYSclMpuU3lCllMm9aEXCtVxt5hxD1wZadNnowUtGfWAoIPGOnWnqKeiXbLoxGHG33eJAoKey9u9Hltll8jJSo+ICOIRkS8kYwhtpYgMOyj8NWMWJUhGvmqNxIKFo2IDLukos6wqh2QEUQjIt5IqK0VCvbtjUQikYiFxAsNL2FNUgwaYAAAAABJRU5ErkJggg==" />
                        <h6>Shape</h6>
                    </button>
                    <button
                        className={`customizecaketablinks ${activeTab === 'flavour' ? 'active' : ''}`}
                        onClick={() => openCustomCakeTab('flavour')}
                    >
                        <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAACXBIWXMAAAsTAAALEwEAmpwYAAAEKklEQVR4nO2bXYhVVRTHVzN6FVMj/CIJNawEBU1SEQmRVHA0nYcoUyEVJAVJU+ihh3pRNBASH3zMEAVnFKHUHoygB4sgiqmJhEoqHbQap9A+xPHrF3vu/8jyMH6cueM0e8/9Pd1Za/a+e+2zz9prr72uWZUqVVIEeA44B7QAy6wvAUwG/uVWdgE1ljrAw8ApGb0beAW4qr8PAw9aqgA1wDEZ+zlQknwBcFHyg5YqwFsy8nfg0ZxunnSXLEWAOuC6lvuzOd1Q4GtNwFFLDWAscF4Gvp7TlYCPpPsRGGkpAQwEvpSB7wMP5HxCo3RngXGWGsC7MvB74KGcbqd0wQE+ZakBrJOBfwOTcro3pGsH5ltqADOAy8AN4MWcboXkwSm+YKkBDAN+1hPekdPN1VMPvGapQdmxHZeBnwH9nW6aXofANksR4G0Z+Csw2snHA79Jt9/vBskA1OvdvgI84+QjgB9k/IdAP0sN4Enggoxc7+RDgK8k/wIYbKkB9AO+lZH7clHexy4OGGGpANSGmF4HnOyEdwYY5JzhAclD4uMxSwFgNLAdaKVzdmly3kkqyqOcyNih4CbjNNDUySScdFHeXIsdYKnbwjJPPgtY7YKaE26Pz4xfajEDjAKOOKM+AWbq/Q6vAdr23gTW5FbBqxYzwBw5r0AbsCoEL/LshyS/FGJ5YADwi8v2BNZarFA+qV2TIWEbe0Tyks70mXPrCHaATZI1Of3zFhtAf2CPDLiupV3jjP9Auj/DaU/yccA/ks8GvtHnqRYTlCO2LDX1F7DE6UrOF7T6bc0dfBq0U1xVzj+ecBcYLC+eHWKm5Iw/6nQ3ExvASjdhY4Dl+vu4xQIwSN4dneGfcDq/7INDnOh0w12ic51kYRXcchbo7sEu1F1aqgTb6u40AS2kz5k7TUAHlih3tY+7/UMfmIAW+vgrUKczd6oE2xZUvlQio7A9VCegjCWCzKmuALtvM5bgCmhXm44amwRS6oHLRRq1qdFwS+MiNXC+SKNmNXraIifYIFuaijRqVKOVFjnAy7LlQJFGm9Voj0UO8J5s2VC01DTLwMaTeurcAWb3DROLNv5ODW/m7mIDWCwbmrvSeJMaf2qR4vKQG7uayGxTB4st3qff2uUCaWCjOvkplJtaJKg0Noy5sgQqZSeSVV80xFB3o+u1BlcxUltph4+7UvOt1ssJY3R3CRO6q9NF7kcHW3vjStCT36IxXrmnzE8RdCsTOkaR4tBe9s5n0WsY40v38+Lkorvl+d9jhDAGVzV6oduffJ5wteXK07NqzXpfsdlDt8z1+m6cwxvfUwOoDRUa7u4u22/3qqxluooXB3TDd5XU13QVUezNFVCFz+sr9vZdIQQYoSDZ1fD1JM2KU3rHr8CASRpQoyo5/nCZpUpoV0TapP19Q+GDTZUqVew2/AciIYH3Ef8ajwAAAABJRU5ErkJggg==" />
                        <h6>Flavour</h6>
                    </button>
                    <button
                        className={`customizecaketablinks ${activeTab === 'color' ? 'active' : ''}`}
                        onClick={() => openCustomCakeTab('color')}
                    >
                        <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAACXBIWXMAAAsTAAALEwEAmpwYAAAFC0lEQVR4nM2aeajVRRTHr/Vce+/la3nZ/iIqE81WK9sogqxXaAURUXiVTAo1IZH+kiJbIWxfzT9CIs2ilSJJgrCsqEwtRGiVtE1zSa2o94nj+/5gmvf73d9vfsu1A5fLnZmzfO/MOXPOzNRqJRJwLFAHHgHeBtYCm4E/6KVt+m3tS4H5wAzgDGBgmbbkMf444F5gHcXod2AJcE1TQQFj9a/2OMb8DCwCZgHjgBFAR2QY0K7fxwMXAVOBp4CVwD+OnF+AucDQKgEcArzkKN0KPC5gexWQOwyYArzvyN4E3AT0KxvEVcBvUrIFmGP/cqlKarv1nAy84QBaBhxUhuB+wJ3OMrIZOTgj7yRgNbBL3/UAveOA76XTvkcWBfGohP0F3BjAe0+CY98dIGM/+WLkg/nAKCIZ7QAuDOA7RzNooXeinLyu39Z+doCsFuAF2fEt0BkK4moxm/ILAnkjxXO9dluiRosC5fUH3hXviyGMRwDbxTglRKn4N4p3uNduoddoQ87ItkX8l2RlekUMz+VxYPmT0RCvfUjkbznlzhD/utSwDJyvwZv9sJfVgTPMyA855bYA36jvvDQglicZzc7rwMDirD4SGhiAOyTj6UYgRjqz0Z7XgT3j6jJukmPcWXnkGgGnqf2zWhIBd2nQQ0UduMRluMFr31ftWxsB+VqDzizJgW02VgE79T2xqFxgkNp3JoHo0oCf4iJCqANnpRyBoVPtG5MEXtdowwlx4EAgQXKBUWpfnSRwngbMSujP7MCBQILkAtfKzoVJAl/VgPFVJoJF5QJPqG9mkrAvNGBUitJUB84Jpp4hMPRXBWkz1ZXmdMWLmIoIuEE2Lms0yE45jNpq/0MCDrQ9JTU9Af7WoL2rqPiKEDDAKbAWpw224qnPxlS1o6cRvRvjy9JlG3ZHGoNthMRVYGVWfIEguiynkl0/AsdkYVojhtFVV3xZCLgM+FXyLaIenZUxmr4rm1HxNbBjIPCwc2rzetCxE3CfGG8rI2HMCaIdeC+SaTVR8MEfcIUELG1Wwhij503n6Of0vEI6NZ12oDy4GQljjE+gP214UWEf7xYFE5qRMHo6npTu62slCLM1afR8s/cReq8VKCWU6zzLdvg/7RypSMKoSu5m4EMtV/us0JFOnzsQei+IjKYXBiKB0bXB7QVkHC6gSWR3Iod5PBPUt7wsIOdKoJ3qHZCDf5AD4nOgG2jVp9vpW+nODDBYpzdGJ5YF5i0JfCAH70wHRGtMfxvwVdwyAh7MqzfJmJPkK/YZE8j7kYzpbjAmWkYrvPaxav+yiP2+svsldI2/r6TwRYffrQ3G2KwYbfPa91H7jqL2++lHdFv7bMlA2hOAdKh9U1H7fYWjnTpldkYeC7dGlzYYc7nGfOC1j4hWQRn2x1349OgzNcP46Oh/VVzZrNmITjSneX2Tgy9zQsgxridtZpSGW2hF0Wm8fKJNTh6BsIJpgMf7mvqqK6GBW5waYX6jAGCbnQMmjgzEoR7PGCdp3b8yIM4y2xWFSOCUlJmZbn6gALBdDwKmxcyEzVYEfE6lIBylp+phDHp68Yy9iCggbyjwjlPSxh5+VEIKzfOcytGSzIWhTzmAi52rtPWWo1VreeOnTUu8RzF22rHAHhdYnaIEsl2PD4bpWdOtwCcOz3LgyD0CwgN0lGr+7wij9Ur1W/Y0hj4EnKDE0WbFKk57R2KviCwiWRn7KfCYQvF/nD4v/Qu0dQj8tJNafgAAAABJRU5ErkJggg==" />
                        <h6>Color</h6>
                    </button>
                    <button
                        className={`customizecaketablinks ${activeTab === 'topping' ? 'active' : ''}`}
                        onClick={() => openCustomCakeTab('topping')}
                    >
                        <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAACXBIWXMAAAsTAAALEwEAmpwYAAADiklEQVR4nO2Ze2iOURzHn80SxmhDbpH7xkTUZhQ2f2yhrMlGK0XulEsu+QN/SGmupUgtEaE0oqH8IVJWlEsjK0nKJWTmfpt9dPg97dd5n2dt8zx7X/V+6633Pb9zfr/veZ7fOb/vOa/jxBFHHHG0FEB/YAlQAiSo9nnAVeA2cBiYASQ6sQSgFPhCI4qlfQHQQCQuAF2dWADQG/huEZwD9AHq8EelEwsAlilS1ZIyCcBp1f4QGA/stt7I9FiYQLkitEbaTJ67MIQnqf77lO14VMkLoZuKUB6QDDxVbeVW/1xlq4ke879k2gGfFaHuwHz1+xWQKn0T5enXK/uVaE8gXZF5Jm1Zsqh/qd3I9LtuLWLTJydsgmYxjgYWypMtArKBHmIvVoQuqnEDDWn5vhH4RiQehE1+mpXLNj5Kirgo8/AxwRrzQz4uMsIiv9WnADWFr8BMy88Q9fSrgEzglBqzIgzyeRb5l8BR4BBwBrgDvPeZhBm3zZISGUC+LOJMkRUu1oYxAb3YKoEuHn3SgBtNvI09Vv8Sj/5mkY8KmvxEFcC8+r4efQZLZdU4JvpGY5f0n+oxQUN+U6DkJdh5vwIk9snAW4vIOrF1srRPvaRPrrV1mjWQHQb5kSr3DbHhlr2DlfufgEJl3+mXSkChSO0/228oAI6owBUedjOBWrE/B8ZZqacrrItLoRG2yPWzJHFOE29pNdBLtRnt80iNrVLfq9tqAntbq08sNfoOGKN+14bHupFAqlRVF/ktGDuOyINMgiUdksOewGYV7J4uQs0Yq6XCSdX+RLUPDZN8R0vPlLbChxF06802qtpuKZ9jAyeuAi1XgcxTSwrI733ld0QQPr2CJAGPVaCVAa6pn+LTKM+UIPx6BZqryL/RKfAPPtubtaD8XguGbWSgBFGVLrYE4DPLOj80AAXBMI4MlmtJgrQAfJ5oSpEGCmBW0IGkBpjcfwEsbcl23NrbhA3AdqBzM8d0AxbJNaInOVGkSU4sQSTxAUk1F7OjRSZRqmfPZvQzt2uXfc7GRW3HWsGckoTAa5MSHvYUYJWlLjXumrtPJxoAesnNgYt0ZRsG7Ac+eJA2Or8CmBIV4tZVidbsphYUmAspnzQxh5cyYIATCwDOKnKGdI1PmhgdsziIyhwogB34w5yBz8kNQnj7dwAiy16cdfKnwyDnfwDQxege4KDcEjSriMURRxxxOC3BbzAbywmodtFvAAAAAElFTkSuQmCC" />
                        <h6>Toppings</h6>
                    </button>
                    <button
                        className={`customizecaketablinks ${activeTab === 'written' ? 'active' : ''}`}
                        onClick={() => openCustomCakeTab('written')}
                    >
                        <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAACXBIWXMAAAsTAAALEwEAmpwYAAACPElEQVR4nO2Zz2sTQRzF12pCSu1Ni+RehFTwT4g9Ck0RbyL1v6jaS1vPkoZS6dmT4KWiFqRVvLRSPPTUSqvJqfQf0P4AIfopQybyJdTdiTuzOyv7YCFk37z3fbMzw+xOEOTIkSMSwCDwBGgBbdyhrT3mlWdgsfhNkscmULIRQPV8Wpi1EUA90i6mgUJs0b97FYCHwu+bDVE55otWKg33Kwq/tg3BP7BSYdKe9CkGjAENYBc41pf6vQBUvA1A59EvRSyz6t5i1Dwi6QC6+PeYYz0sBCkEUD0vsQJUgSF93QJe9XAWvQigx7wcNtMhWnKJVG0qPgRoyJ430Hst+HUfAnwRlKqB3rjg7/gQ4EhQLhvoDQv+Dx8CnApK5A5ST+ouTnwIcCgoowZ61wX/wIcAa4Jyz0DvvuC/8yGA3G6/MNB7KfhzPgS4Kcc0MBKida1nztxIPYDmbAvaUgjvmeB9juNpO0BN0H4Bk+dw7gC/BW/CpwAXgLeC+hN4rIeMumb0f128ietpDFMx4CqwTzT2gCveBVAAysCnkOI3FCeIAGkF0PyLwAP9FtbFV2BK3XPh6UQMuCuabql50kfbf/K0KqbGec+aX3PtaV0MeCqaf8higHLU1tn3AHLn+T0JT5tzYABYFc0/Zi1AQ7YFbrv2tCamtxZyBXru2tPFE6jrz4rLwKXMBYgDLAfI/Of1lhB85DIEneLVNtzqAYc6cMv0EdNgSod8G1YO+XSIkuoNoJnAMWtTe9kpPkeO/xxnz5p6PjSMD/kAAAAASUVORK5CYII=" />
                        <h6>Message</h6>
                    </button>
                </div>
                <div
                    id="shape"
                    className="customizecaketabcontent"
                    style={{ display: activeTab === 'shape' ? 'block' : 'none' }}
                >
                    <div className="customize-content">
                        <div className="shape-content">
                            <div className="shape-preview">
                                {['shape1', 'shape2', 'shape3', 'shape4', 'shape5', 'shape6', 'shape7', 'shape8'].map((shape) => (
                                    <div id={shape} className="tabshapescontent" style={{ display: activeShape === shape ? 'block' : 'none' }} key={shape}>
                                        <img src="assets/images/shape-1.png" alt="" />
                                    </div>
                                ))}
                            </div>

                            <div className="row shapes-tab justify-content-md-center">
                                {['shape1', 'shape2', 'shape3', 'shape4', 'shape5', 'shape6', 'shape7', 'shape8'].map((shape) => (
                                    <button className="col-md-auto tabshapeslinks" onClick={() => openShapes(shape)} key={shape}>
                                        <div className="shapes-button">
                                            <img src="assets/images/shape-1.png" alt="" />
                                            <h1>Mini Standard</h1>
                                            <h2>Good for 5 people</h2>
                                            <h3>1kg | 6x5x3</h3>
                                            <h4>180 SAR</h4>
                                        </div>
                                    </button>
                                ))}
                            </div>

                            <div className="next-btn"><button>Next</button></div>
                        </div>
                    </div>
                </div>
                <div id="flavour" className="customizecaketabcontent" style={{ display: activeTab === 'flavour' ? 'block' : 'none' }}>
                    <div className="customize-content">
                        <div className="flavour-content">
                            <div className="flavour-preview">
                                {['flavour1', 'flavour2', 'flavour3', 'flavour4'].map((flavour) => (
                                    <div
                                        key={flavour}
                                        id={flavour}
                                        className="tabflavourcontent"
                                        style={{ display: activeFlavour === flavour ? 'block' : 'none' }}
                                    >
                                        <img src="assets/images/shape-1.png" alt="" />
                                    </div>
                                ))}
                                {['flavour5', 'flavour6', 'flavour7'].map((flavour) => (
                                    <div
                                        key={flavour}
                                        id={flavour}
                                        className="tabflavourcontent"
                                        style={{ display: activeFlavour === flavour ? 'block' : 'none' }}
                                    >
                                        <img src="assets/images/flavour-1.png" alt="" />
                                    </div>
                                ))}
                            </div>

                            <div className="row flavour-tab justify-content-md-center">
                                {['flavour1', 'flavour2', 'flavour3', 'flavour4', 'flavour5', 'flavour6', 'flavour7'].map((flavour) => (
                                    <button
                                        key={flavour}
                                        className={`col-md-auto tabflavourlinks${activeFlavour === flavour ? ' active' : ''}`}
                                        onClick={(evt) => openFlavours(evt, flavour)}
                                    >
                                        <div className="flavour-button">
                                            <img src="assets/images/flavour.png" alt="" />
                                            <h1>Mini Standard</h1>
                                        </div>
                                    </button>
                                ))}
                            </div>

                            <div className="next-btn">
                                <button>Next</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="color" className="customizecaketabcontent" style={{ display: activeTab === 'color' ? 'block' : 'none' }}>
                    <div className="customize-content">
                        <div className="color-content">
                            <div className="color-preview">
                                <div id="color1" className="tabcolorcontent" style={{ display: activeColor === 'color1' ? 'block' : 'none' }}>
                                    <img src="assets/images/topping-1.png" alt="" />
                                </div>
                                <div id="color2" className="tabcolorcontent" style={{ display: activeColor === 'color2' ? 'block' : 'none' }}>
                                    <img src="assets/images/topping-1.png" alt="" />
                                </div>
                                <div id="color3" className="tabcolorcontent" style={{ display: activeColor === 'color3' ? 'block' : 'none' }}>
                                    <img src="assets/images/topping-2.png" alt="" />
                                </div>
                                <div id="color4" className="tabcolorcontent" style={{ display: activeColor === 'color4' ? 'block' : 'none' }}>
                                    <img src="assets/images/topping-1.png" alt="" />
                                </div>
                                <div id="color5" className="tabcolorcontent" style={{ display: activeColor === 'color5' ? 'block' : 'none' }}>
                                    <img src="assets/images/topping-4.png" alt="" />
                                </div>
                                <div id="color6" className="tabcolorcontent" style={{ display: activeColor === 'color6' ? 'block' : 'none' }}>
                                    <img src="assets/images/topping-1.png" alt="" />
                                </div>
                                <div id="color7" className="tabcolorcontent" style={{ display: activeColor === 'color7' ? 'block' : 'none' }}>
                                    <img src="assets/images/topping-1.png" alt="" />
                                </div>
                                <div id="color8" className="tabcolorcontent" style={{ display: activeColor === 'color8' ? 'block' : 'none' }}>
                                    <img src="assets/images/topping-1.png" alt="" />
                                </div>
                                <div id="color9" className="tabcolorcontent" style={{ display: activeColor === 'color9' ? 'block' : 'none' }}>
                                    <img src="assets/images/topping-1.png" alt="" />
                                </div>
                                <div id="color10" className="tabcolorcontent" style={{ display: activeColor === 'color10' ? 'block' : 'none' }}>
                                    <img src="assets/images/topping-1.png" alt="" />
                                </div>
                                <div id="color11" className="tabcolorcontent" style={{ display: activeColor === 'color11' ? 'block' : 'none' }}>
                                    <img src="assets/images/topping-1.png" alt="" />
                                </div>
                                <div id="color12" className="tabcolorcontent" style={{ display: activeColor === 'color12' ? 'block' : 'none' }}>
                                    <img src="assets/images/topping-1.png" alt="" />
                                </div>
                                <div id="color13" className="tabcolorcontent" style={{ display: activeColor === 'color13' ? 'block' : 'none' }}>
                                    <img src="assets/images/topping-5.png" alt="" />
                                </div>
                                <div id="color14" className="tabcolorcontent" style={{ display: activeColor === 'color14' ? 'block' : 'none' }}>
                                    <img src="assets/images/topping-1.png" alt="" />
                                </div>
                                <div id="color15" className="tabcolorcontent" style={{ display: activeColor === 'color15' ? 'block' : 'none' }}>
                                    <img src="assets/images/topping-1.png" alt="" />
                                </div>
                            </div>
                            <div className="row color-tab justify-content-md-center">
                                {['color1', 'color2', 'color3', 'color4', 'color5', 'color6', 'color7', 'color8', 'color9', 'color10', 'color11', 'color12', 'color13', 'color14', 'color15'].map((color, index) => (
                                    <button key={index} className={`col-md-auto tabcolorlinks ${activeColor === color ? 'active' : ''}`} onClick={(e) => openColors(e, color)}>
                                        <div className="color-button" style={{ backgroundColor: ['#FFFFFF', '#BAEDFF', '#D4E4C7', '#F9DDD9', '#FADA87', '#F8E4C3', '#20C4E9', '#7EBD77', '#F4BAB9', '#FF8838', '#FFDDAD', '#1F4278', '#4DAE43', '#FC72A6'][index], border: color === 'color1' ? '2px solid rgb(196, 196, 196)' : 'none' }}></div>
                                    </button>
                                ))}
                                <button className="col-md-auto tabcolorlinks" onClick={(e) => openColors(e, 'custom')}>
                                    <div className="color-picker-wrapper">
                                        <div className="choose-color-pencil">
                                            <svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="24" height="24" viewBox="0,0,256,256" style={{ fill: '#000000' }}>
                                                <g fill="#48695f" fillRule="nonzero" stroke="none" strokeWidth="1" strokeLinecap="butt" strokeLinejoin="miter" strokeMiterlimit="10" strokeDasharray="" strokeDashoffset="0" fontFamily="none" fontWeight="none" fontSize="none" textAnchor="none" style={{ mixBlendMode: 'normal' }}>
                                                    <g transform="scale(10.66667,10.66667)">
                                                        <path d="M18.41406,2c-0.256,0 -0.51203,0.09797 -0.70703,0.29297l-2,2l-1.41406,1.41406l-11.29297,11.29297v4h4l14.70703,-14.70703c0.391,-0.391 0.391,-1.02406 0,-1.41406l-2.58594,-2.58594c-0.195,-0.195 -0.45103,-0.29297 -0.70703,-0.29297zM18.41406,4.41406l1.17188,1.17188l-1.29297,1.29297l-1.17187,-1.17187zM15.70703,7.12109l1.17188,1.17188l-10.70703,10.70703h-1.17187v-1.17187z"></path>
                                                    </g>
                                                </g>
                                            </svg>
                                        </div>
                                        <input type="color" id="favcolor" name="favcolor" value={customColor} onChange={handleColorChange} />
                                    </div>
                                </button>
                            </div>
                            <div className="next-btn"><button>Next</button></div>
                        </div>
                    </div>
                </div>
                <div id="topping" className="customizecaketabcontent" style={{ display: activeTab === 'topping' ? 'block' : 'none' }}>
                    <div className="customize-content">
                        <div className="topping-content">
                            <div className="topping-preview">
                                <div
                                    id="topping1"
                                    className="tabtoppingcontent"
                                    style={{ display: activeTopping === 'topping1' ? 'block' : 'none' }}
                                >
                                    <img src="assets/images/topping-1.png" alt="" />
                                </div>

                                <div
                                    id="topping2"
                                    className="tabtoppingcontent"
                                    style={{ display: activeTopping === 'topping2' ? 'block' : 'none' }}
                                >
                                    <img src="assets/images/topping-2.png" alt="" />
                                </div>

                                <div
                                    id="topping3"
                                    className="tabtoppingcontent"
                                    style={{ display: activeTopping === 'topping3' ? 'block' : 'none' }}
                                >
                                    <img src="assets/images/topping-3.png" alt="" />
                                </div>

                                <div
                                    id="topping4"
                                    className="tabtoppingcontent"
                                    style={{ display: activeTopping === 'topping4' ? 'block' : 'none' }}
                                >
                                    <img src="assets/images/topping-4.png" alt="" />
                                </div>

                                <div
                                    id="topping5"
                                    className="tabtoppingcontent"
                                    style={{ display: activeTopping === 'topping5' ? 'block' : 'none' }}
                                >
                                    <img src="assets/images/topping-1.png" alt="" />
                                </div>

                                <div
                                    id="flavor6"
                                    className="tabtoppingcontent"
                                    style={{ display: activeTopping === 'flavor6' ? 'block' : 'none' }}
                                >
                                    <img src="assets/images/topping-1.png" alt="" />
                                </div>

                                <div
                                    id="topping7"
                                    className="tabtoppingcontent"
                                    style={{ display: activeTopping === 'topping7' ? 'block' : 'none' }}
                                >
                                    <img src="assets/images/topping-1.png" alt="" />
                                </div>

                                <div
                                    id="topping8"
                                    className="tabtoppingcontent"
                                    style={{ display: activeTopping === 'topping8' ? 'block' : 'none' }}
                                >
                                    <img src="assets/images/topping-1.png" alt="" />
                                </div>

                                <div
                                    id="topping9"
                                    className="tabtoppingcontent"
                                    style={{ display: activeTopping === 'topping9' ? 'block' : 'none' }}
                                >
                                    <img src="assets/images/topping-1.png" alt="" />
                                </div>

                                <div
                                    id="topping10"
                                    className="tabtoppingcontent"
                                    style={{ display: activeTopping === 'topping10' ? 'block' : 'none' }}
                                >
                                    <img src="assets/images/topping-1.png" alt="" />
                                </div>
                            </div>

                            <div className="row topping-tab justify-content-md-center">
                                {Array.from({ length: 10 }, (_, i) => (
                                    <button
                                        key={i}
                                        className={`col-md-auto tabtoppinglinks ${activeTopping === `topping${i + 1}` ? 'active' : ''}`}
                                        onClick={(event) => opentoppings(event, `topping${i + 1}`)}
                                    >
                                        <div className="topping-button">
                                            <img src="assets/images/topping-1.png" alt="" />
                                            <h1>Topping</h1>
                                            <h2>+100SAR</h2>
                                        </div>
                                    </button>
                                ))}
                            </div>

                            <div className="next-btn">
                                <button>Next</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div
                    id="written"
                    className="customizecaketabcontent"
                    style={{ display: activeTab === 'written' ? 'block' : 'none', width: "100%" }}
                >
                    <div className="customize-form">
                        <div className="form-content">
                            <img src="assets/images/topping-1.png" alt="" />
                            <div className="form-container">
                                <form action="#">
                                    <input type="text" placeholder="Write on cake" />
                                    <br />
                                    <br />
                                    <div className="upload-something-container">
                                        <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAACXBIWXMAAAsTAAALEwEAmpwYAAACKUlEQVR4nO1WTWsUQRCdQ/SiaLzqVaPgwa/4N4z+FjV6z8dVDLksJOp5mH6vh10W1jUO/gk38aQm1wQ0ZnMykSc1uKDO9ExmMUIeNDT0q4+uqu6qKDrB/wTv/VWSTwC8ITkA8E3L9n2SswCmxmF4muQaycOQZQ7eObLhVqt1iuQygANTvg1gxXt/T9Ho9XpntLQHMENyVRxz4gDAUpZlE7WMdzqdCwDemrI9knPdbvdcmZw4JOdJDkeiMVnn5mumYEspqHoB59wNkh9Nx7s4jk8HC5NcNsHP3vuLUU1IluSmpe95qNC05W/Pe38rOiKcc7ctHd+1LxXgr2qfixoCgAWLaD/knR+qkkMKLn92Zbw4js8D2BE3SZIrRZ4+NU9XypRWccB0vzDdj4tIfSPNNO2A9/6B8V8XKfwgUpqml8fgwM/0AlgvUrgrUhzHZ4sMlq0/yUqnne/+1QEAX8flgP2QisCXoghsGGmq6RQkSXLN+IN/XYS9IoWzRlpt2gGSr4z/8Ph+RIK1TymejxoCycXS8OfQJGMDyDCoeYRNU/tqRiRvBgkBWDKPN9vt9qW6xiWbt2MAz4IFsyybyFOhgcQ5d7eqcd0WwKe8C1YezUhOjtTDUC1VxVQmJ47lfD//+yuPZDnktSYZy59usgPgJcn7+lj0Y2ppr3eus7zaJaOw1x5KR5Gm6XWS7Qpjeb+JAv4NesPq5xbWgTUvrfd6YiQfhXbSExwb/AA7QOZqDlLY/gAAAABJRU5ErkJggg==" />
                                        <h1>Upload something to print..</h1>
                                    </div>
                                    <br />
                                    <br />
                                    <h2>+100 SAR</h2>
                                    <h3>
                                        We will make sure to place it in the right position on the cake..
                                    </h3>
                                    <br />
                                    <div className="additional-guide-container">
                                        <div
                                            style={{
                                                display: "flex",
                                                flexDirection: "row",
                                                justifyContent: "center",
                                                alignItems: "center"
                                            }}
                                        >
                                            <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAn0lEQVR4nO3WMQrCQBCF4U978RIWHsVg4YG8gJex8So21sZa8AC6IiSQwiprshHmh4Hlwc48mFl2CIKJkUaK6RsYijCQogV6DOEWN9SoMvTeQ1h39GuG/r8GqibpJ9kmQ+9t4JeEgRQtkPEdt6xwLrEPtE/sPuQ+8I320h7P5nzEwkikTrxwwHys4jrFH9gpQMIFa4U4Yakgs5LFA0PzBgslzu4ddFV1AAAAAElFTkSuQmCC" />
                                            <h5>Additional Guide</h5>
                                        </div>
                                        <textarea
                                            id="example-textarea"
                                            rows={2}
                                            cols={5}
                                            placeholder="Message : Write the message on the cake."
                                            defaultValue={""}
                                        />
                                    </div>
                                    <br />
                                    <Link to="/cart" style={{textDecoration:'none'}}>
                                    <div className="go-to-cart"><span>Go to Cart</span></div></Link>
                                </form>
                                <br />
                                <br />
                                <br />
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </>

    );
}

export default Home;
