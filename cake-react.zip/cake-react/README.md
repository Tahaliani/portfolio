## DEPLOYMENT

### Build & Push
```shell
export AWS_DEFAULT_PROFILE=erratic
aws ecr get-login-password --region ap-south-1 | docker login --username AWS --password-stdin 538134686127.dkr.ecr.ap-south-1.amazonaws.com
docker buildx build --platform linux/amd64 -t 538134686127.dkr.ecr.ap-south-1.amazonaws.com/erratic:user --push .
```

### Deployment
```shell
aws ecr get-login-password --region ap-south-1 | sudo docker login --username AWS --password-stdin 538134686127.dkr.ecr.ap-south-1.amazonaws.com
sudo docker pull 538134686127.dkr.ecr.ap-south-1.amazonaws.com/erratic:user
# Close the previous containers

sudo docker run -d -p 3000:3000 538134686127.dkr.ecr.ap-south-1.amazonaws.com/erratic:user
```
